# Requirements
- Set up mlab.com
- Set up heroku puppeteer buildpack.
- Update config.json